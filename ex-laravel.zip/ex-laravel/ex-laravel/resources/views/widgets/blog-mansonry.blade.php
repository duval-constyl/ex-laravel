<!-- Pagination -->
<ul class="pagination justify-content-center mb-4">
    {{$posts->links("pagination::bootstrap-4")}}
</ul>